

<?php $__env->startSection('title', 'Solis Inverter Indonesia - Solusi Energi Terbarukan Terbaik'); ?>

<?php $__env->startSection('content'); ?>
    <div class="min-h-screen bg-white">
        <?php if (isset($component)) { $__componentOriginal04f02f1e0f152287a127192de01fe241 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal04f02f1e0f152287a127192de01fe241 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.hero','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('hero'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal04f02f1e0f152287a127192de01fe241)): ?>
<?php $attributes = $__attributesOriginal04f02f1e0f152287a127192de01fe241; ?>
<?php unset($__attributesOriginal04f02f1e0f152287a127192de01fe241); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal04f02f1e0f152287a127192de01fe241)): ?>
<?php $component = $__componentOriginal04f02f1e0f152287a127192de01fe241; ?>
<?php unset($__componentOriginal04f02f1e0f152287a127192de01fe241); ?>
<?php endif; ?>
        <?php if (isset($component)) { $__componentOriginal2f906c7b72b7f488716a138bd805a1ae = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal2f906c7b72b7f488716a138bd805a1ae = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.about-section','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('about-section'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal2f906c7b72b7f488716a138bd805a1ae)): ?>
<?php $attributes = $__attributesOriginal2f906c7b72b7f488716a138bd805a1ae; ?>
<?php unset($__attributesOriginal2f906c7b72b7f488716a138bd805a1ae); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal2f906c7b72b7f488716a138bd805a1ae)): ?>
<?php $component = $__componentOriginal2f906c7b72b7f488716a138bd805a1ae; ?>
<?php unset($__componentOriginal2f906c7b72b7f488716a138bd805a1ae); ?>
<?php endif; ?>
        <?php if (isset($component)) { $__componentOriginal05fc53a23296c7496b3765fe64fd4b35 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal05fc53a23296c7496b3765fe64fd4b35 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.category-section','data' => ['categories' => $categories]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('category-section'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['categories' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($categories)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal05fc53a23296c7496b3765fe64fd4b35)): ?>
<?php $attributes = $__attributesOriginal05fc53a23296c7496b3765fe64fd4b35; ?>
<?php unset($__attributesOriginal05fc53a23296c7496b3765fe64fd4b35); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal05fc53a23296c7496b3765fe64fd4b35)): ?>
<?php $component = $__componentOriginal05fc53a23296c7496b3765fe64fd4b35; ?>
<?php unset($__componentOriginal05fc53a23296c7496b3765fe64fd4b35); ?>
<?php endif; ?>
        <?php if (isset($component)) { $__componentOriginal15ef7b5a07a6d598c5349a1e82c1f3de = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal15ef7b5a07a6d598c5349a1e82c1f3de = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.features-bento','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('features-bento'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal15ef7b5a07a6d598c5349a1e82c1f3de)): ?>
<?php $attributes = $__attributesOriginal15ef7b5a07a6d598c5349a1e82c1f3de; ?>
<?php unset($__attributesOriginal15ef7b5a07a6d598c5349a1e82c1f3de); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal15ef7b5a07a6d598c5349a1e82c1f3de)): ?>
<?php $component = $__componentOriginal15ef7b5a07a6d598c5349a1e82c1f3de; ?>
<?php unset($__componentOriginal15ef7b5a07a6d598c5349a1e82c1f3de); ?>
<?php endif; ?>
        <?php if (isset($component)) { $__componentOriginal665ae12b0bd07fab9260e6b4fc71b6ef = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal665ae12b0bd07fab9260e6b4fc71b6ef = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.featured-products','data' => ['products' => $featuredProducts]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('featured-products'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['products' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($featuredProducts)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal665ae12b0bd07fab9260e6b4fc71b6ef)): ?>
<?php $attributes = $__attributesOriginal665ae12b0bd07fab9260e6b4fc71b6ef; ?>
<?php unset($__attributesOriginal665ae12b0bd07fab9260e6b4fc71b6ef); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal665ae12b0bd07fab9260e6b4fc71b6ef)): ?>
<?php $component = $__componentOriginal665ae12b0bd07fab9260e6b4fc71b6ef; ?>
<?php unset($__componentOriginal665ae12b0bd07fab9260e6b4fc71b6ef); ?>
<?php endif; ?>
        <?php if (isset($component)) { $__componentOriginal647b175ed9e08e7e2da03809063e0558 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal647b175ed9e08e7e2da03809063e0558 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.contact-section','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('contact-section'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal647b175ed9e08e7e2da03809063e0558)): ?>
<?php $attributes = $__attributesOriginal647b175ed9e08e7e2da03809063e0558; ?>
<?php unset($__attributesOriginal647b175ed9e08e7e2da03809063e0558); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal647b175ed9e08e7e2da03809063e0558)): ?>
<?php $component = $__componentOriginal647b175ed9e08e7e2da03809063e0558; ?>
<?php unset($__componentOriginal647b175ed9e08e7e2da03809063e0558); ?>
<?php endif; ?>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\solisinverterindonesia\laravel_app\resources\views/index.blade.php ENDPATH**/ ?>